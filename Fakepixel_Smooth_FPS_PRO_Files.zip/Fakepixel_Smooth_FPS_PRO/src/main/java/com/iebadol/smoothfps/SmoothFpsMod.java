package com.iebadol.smoothfps;

import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.io.File;

@Mod(modid = SmoothFpsMod.MODID, name = SmoothFpsMod.NAME, version = SmoothFpsMod.VERSION,
        acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public final class SmoothFpsMod {
    public static final String MODID = "fakepixel_smooth_fps_pro";
    public static final String NAME = "Fakepixel Smooth FPS PRO";
    public static final String VERSION = "2.0.0";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        File configFile = new File(event.getModConfigurationDirectory(), "Fakepixel_Smooth_FPS_PRO.cfg");
        ModConfig.load(configFile);
        if (event.getSide() == Side.CLIENT) {
            ClientOptimizer optimizer = new ClientOptimizer();
            FMLCommonHandler.instance().bus().register(optimizer);
            MinecraftForge.EVENT_BUS.register(optimizer);
        }
    }
}
