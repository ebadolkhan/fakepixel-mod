package com.iebadol.smoothfps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Applies reversible vanilla client settings only; it does not replace renderers or game assets. */
@SideOnly(Side.CLIENT)
public final class ClientOptimizer {
    private boolean snapshotValid;
    private int oldParticleSetting;
    private boolean oldEntityShadows;
    private int oldRenderDistance;
    private int oldFpsLimit;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null) return;

        if (mc.theWorld == null) {
            restore(mc.gameSettings);
            return;
        }

        if (!snapshotValid) capture(mc.gameSettings);
        apply(mc.gameSettings);
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        if (event.world != null && event.world.isRemote) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc != null && mc.gameSettings != null) restore(mc.gameSettings);
        }
    }

    private void capture(GameSettings settings) {
        oldParticleSetting = settings.particleSetting;
        oldEntityShadows = settings.entityShadows;
        oldRenderDistance = settings.renderDistanceChunks;
        oldFpsLimit = settings.limitFramerate;
        snapshotValid = true;
    }

    private void apply(GameSettings settings) {
        if (ModConfig.reduceParticles) settings.particleSetting = 2;
        if (ModConfig.disableEntityShadows) settings.entityShadows = false;
        if (ModConfig.renderDistanceChunks > 0) settings.renderDistanceChunks = ModConfig.renderDistanceChunks;
        if (ModConfig.fpsLimit > 0) settings.limitFramerate = ModConfig.fpsLimit;
    }

    private void restore(GameSettings settings) {
        if (!snapshotValid) return;
        settings.particleSetting = oldParticleSetting;
        settings.entityShadows = oldEntityShadows;
        settings.renderDistanceChunks = oldRenderDistance;
        settings.limitFramerate = oldFpsLimit;
        snapshotValid = false;
    }
}
