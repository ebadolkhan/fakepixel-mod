package com.iebadol.smoothfps;

import net.minecraftforge.common.config.Configuration;
import java.io.File;

public final class ModConfig {
    private static Configuration config;

    public static boolean reduceParticles = true;
    public static boolean disableEntityShadows = true;
    public static int renderDistanceChunks = 8;
    public static int fpsLimit = 60;

    private ModConfig() { }

    public static void load(File file) {
        config = new Configuration(file);
        sync();
    }

    public static void sync() {
        reduceParticles = config.getBoolean("reduceParticles", "performance",
                true, "Use Minecraft's minimal-particles mode while in a world.");
        disableEntityShadows = config.getBoolean("disableEntityShadows", "performance",
                true, "Disable entity shadows to reduce rendering work.");
        renderDistanceChunks = config.getInt("renderDistanceChunks", "performance",
                8, 0, 16, "Render distance in chunks. Set to 0 to leave the game setting unchanged.");
        fpsLimit = config.getInt("fpsLimit", "performance",
                60, 0, 120, "FPS cap while in a world. Set to 0 to leave the game setting unchanged.");
        if (config.hasChanged()) {
            config.save();
        }
    }
}
